#!/usr/bin/env python
# coding: utf-8

# Dream Housing Finance company deals in all home loans. They have presence across all urban, semi urban and rural areas. 
# Customer first apply for home loan after that company validates the customer eligibility for loan.
# 
# Problem
# Company wants to automate the loan eligibility process (real time) based on customer detail provided while filling online application form. These details are Gender, Marital Status, Education, Number of Dependents, Income, Loan Amount, Credit History and others. To automate this process, they have given a problem to identify the customers segments, those are eligible for loan amount so that they can specifically target these customers. Here they have provided a partial data set.
# 
# 
# Variable - Description
# Loan_ID - Unique Loan ID
# Gender - Male/ Female
# Married - Applicant married (Y/N)
# Dependents - Number of dependents
# Education - Applicant Education (Graduate/ Under Graduate)
# Self_Employed - Self employed (Y/N)
# ApplicantIncome  - Applicant income
# CoapplicantIncome - Coapplicant income
# LoanAmount - Loan amount in thousands
# Loan_Amount_Term - Term of loan in months
# Credit_History - credit history meets guidelines
# Property_Area - Urban/ Semi Urban/ Rural
# Loan_Status - Loan approved (Y/N)

# Importing the Libs
import pandas as pd
import numpy as np
import scipy as sc
from sklearn.ensemble import RandomForestClassifier
train = pd.read_csv('train_loan.csv')
test = pd.read_csv('test_loan.csv')
train['Loan_Status'] = train['Loan_Status'].apply(lambda x: 0 if x=='N' else 1 )
train['Self_Employed'].fillna((train['Self_Employed'].mode()[0]), inplace=True)
train['Self_Employed'] = train['Self_Employed'].apply(lambda x: 0 if x=='No' else 1 )
train['LoanAmount'].fillna((train['LoanAmount'].mean()), inplace=True)
train['Dependents'] =  train['Dependents'].replace('3+',3)
train['Dependents'].fillna((train['Dependents'].mode()[0]), inplace=True)
train['Credit_History'].fillna((train['Credit_History'].mode()[0]), inplace=True)
train['Gender'].fillna((train['Gender'].mode()[0]), inplace=True)
train['Gender'] = train['Gender'].astype("category")
train['Loan_Amount_Term'].fillna((train['Loan_Amount_Term'].mode()[0]), inplace=True)
train['Education'] = train['Education'].astype("category")
train['Property_Area'] = train['Property_Area'].astype("category")
train=train[((train.ApplicantIncome - train.ApplicantIncome.mean()) / train.ApplicantIncome.std()).abs() < 3]
train=train[((train.CoapplicantIncome - train.CoapplicantIncome.mean()) / train.CoapplicantIncome.std()).abs() < 3]
train['Total_Income'] = train['ApplicantIncome'] + train['CoapplicantIncome']
train['LoanAmtPerMon'] = train['LoanAmount'] / train['Loan_Amount_Term']
train['TotIncomeByLoan'] =  train['Total_Income'] /  train['LoanAmount']
new_train=train
new_train_loan_Status = new_train['Loan_Status']
new_train=new_train.drop(['Loan_Status'],axis=1)
new_train=new_train.drop(['Loan_ID'],axis=1)


#Test
test['Self_Employed'].fillna((test['Self_Employed'].mode()[0]), inplace=True)
test['Self_Employed'] = test['Self_Employed'].apply(lambda x: 0 if x=='No' else 1 )
test['LoanAmount'].fillna((test['LoanAmount'].mean()), inplace=True)
test['Dependents'] =  test['Dependents'].replace('3+',3)
test['Dependents'].fillna((test['Dependents'].mode()[0]), inplace=True)
test['Credit_History'].fillna((test['Credit_History'].mode()[0]), inplace=True)
test['Gender'].fillna((test['Gender'].mode()[0]), inplace=True)
test['Gender'] = test['Gender'].astype("category")
test['Loan_Amount_Term'].fillna((test['Loan_Amount_Term'].mode()[0]), inplace=True)
test['Education'] = test['Education'].astype("category")
test['Property_Area'] = test['Property_Area'].astype("category")
test['Total_Income'] = test['ApplicantIncome'] + test['CoapplicantIncome']
test['LoanAmtPerMon'] = test['LoanAmount'] / test['Loan_Amount_Term']
test['TotIncomeByLoan'] =  test['Total_Income'] /  test['LoanAmount']
loan_id_list=test['Loan_ID']
new_test=test.drop(['Loan_ID'],axis=1)
#Mark New Train with Training Column and Test with Test Column. If we use get_dummies on different data set
#Its possible that data set cannot match due to categorical values
new_train['Label'] = 1
new_test['Label'] = 0
# Concat
concat_df = pd.concat([new_train , new_test])
# Create your dummies
features_df = pd.get_dummies(concat_df)
# Split your data
train_df = features_df[features_df['Label'] == 1]
train_df=train_df.drop(['Label'],axis=1)
test_df = features_df[features_df['Label'] == 0]
test_df= test_df.drop(['Label'],axis=1)
#Running Random Forest
Random_forest = RandomForestClassifier(n_estimators=100, random_state = 42).fit(train_df,new_train_loan_Status)
pred_Random_forest = Random_forest.predict(test_df)
pred_Random_forest
final_test=test
final_test['Loan_Status']=pred_Random_forest
#Convert 1 0 to Y N
final_test.Loan_Status[final_test.Loan_Status == 1 ] = 'Y'
final_test.Loan_Status[final_test.Loan_Status == 0 ] = 'N'
final_test['Loan_ID']=loan_id_list
final_test[['Loan_ID','Loan_Status']].to_csv('AkFinal1.csv',index=False)

